﻿namespace bysj
{
    public class bysjConsts
    {
        public const string LocalizationSourceName = "bysj";

        public const bool MultiTenancyEnabled = true;
    }
}