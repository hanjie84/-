﻿(function () {
    var controllerId = 'app.views.layout.sidebarFooter';
    angular.module('app').controller(controllerId, [
        '$rootScope', '$state', 'appSession',
        function ($rootScope, $state, appSession) {
            var vm = this;

        }
    ]);
})();